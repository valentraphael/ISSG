const socket = require("socket.io-client");
const readlineInterface = require("readline");
const cryptoModule = require("crypto");

const { publicKey, privateKey } = cryptoModule.generateKeyPairSync("rsa", {
  modulusLength: 512,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

const socketConnection = socket("http://localhost:3000");

const rl = readlineInterface.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let currentTarget = ""; 
let currentUser = ""; 
const connectedUsers = new Map();

socketConnection.on("connect", () => {
  console.log("Connected to the chat server");

  rl.question("Choose a username: ", (input) => {
    currentUser = input;
    console.log(`Hello, ${currentUser}!`);

    socketConnection.emit("registerKey", {
      username: currentUser,
      publicKey: publicKey,
    });
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        if (message.startsWith("!secret ")) {
          currentTarget = message.split(" ")[1];
          console.log(`Secret chat with ${currentTarget} started.`);
        } else if (message === "!exit") {
          console.log(`Exited secret chat with ${currentTarget}`);
          currentTarget = "";
        } else {
          if (currentTarget) {
            const encryptedMessage = encrypt(message, currentTarget);
            if (encryptedMessage) {
              socketConnection.emit("privateMessage", { sender: currentUser, target: currentTarget, message: encryptedMessage });
            }
          } else {
            socketConnection.emit("broadcastMessage", { username: currentUser, message });
          }
        }
      }
      rl.prompt();
    });
  });
});

socketConnection.on("init", (clients) => {
  clients.forEach(([user, data]) => connectedUsers.set(user, data.publicKey));
  console.log(`Currently ${connectedUsers.size} users are online.`);
  rl.prompt();
});

socketConnection.on("userJoined", (data) => {
  const { username, publicKey } = data;
  connectedUsers.set(username, publicKey);
  console.log(`${username} joined the chat.`);
  rl.prompt();
});

socketConnection.on("broadcastMessage", (data) => {
  const { username, message } = data;
  if (username !== currentUser) {
    console.log(`${username}: ${message}`);
    rl.prompt();
  }
});

socketConnection.on("privateMessage", (data) => {
  const { sender, target, message } = data;

  if (target === currentUser) {
    const decryptedMessage = decrypt(message);
    console.log(`[Private from ${sender}]: ${decryptedMessage}`);
  } else {
    console.log(message);
  }
  rl.prompt();
});

socketConnection.on("userLeft", (data) => {
  const { username } = data;
  connectedUsers.delete(username);
  console.log(`${username} has left the chat.`);
  rl.prompt();
});

socketConnection.on("disconnect", () => {
  console.log("Disconnected from the server. Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socketConnection.disconnect();
  rl.close();
  process.exit(0);
});

function encrypt(message, target) {
  const targetPublicKey = connectedUsers.get(target);
  if (!targetPublicKey) {
    console.error(`No public key found for ${target}. Ensure ${target} is connected.`);
    return null;
  }
  const encrypted = cryptoModule.publicEncrypt(targetPublicKey, Buffer.from(message));
  return encrypted.toString("base64");
}

function decrypt(encryptedMessage) {
  const decrypted = cryptoModule.privateDecrypt(privateKey, Buffer.from(encryptedMessage, "base64"));
  return decrypted.toString("utf8");
}
