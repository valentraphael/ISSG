const http = require("http");
const socketIo = require("socket.io");
const crypto = require("crypto");

const server = http.createServer();
const io = socketIo(server);

const users = new Map();  // Store users and their public keys

io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`);

  // Send initial user list to new clients
  socket.emit("init", Array.from(users.entries()));

  // Register public key when a client joins
  socket.on("registerPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} registered with public key.`);

    io.emit("newUser", { username, publicKey });
  });

  // Handle incoming messages with signature
  socket.on("message", (data) => {
    const { username, message, signature } = data;
    
    // If no signature or message, warn about possible impersonation
    if (!signature || !message) {
      console.log(`WARNING: Message from ${username} without signature. Possible impersonation!`);
      return;
    }

    // Forward the message and signature to all clients
    io.emit("message", { username, message, signature });
  });

  socket.on("disconnect", () => {
    console.log(`Client ${socket.id} disconnected`);
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
