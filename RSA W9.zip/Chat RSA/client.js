const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let registeredUsername = "";
let username = "";
let realUsername = "";  // Store the real username for signing messages.
let impersonating = false;  // Track if the user is impersonating
const users = new Map();

// Generate RSA keys for this client
const { generateKeyPairSync } = crypto;
const { privateKey: priv, publicKey: pub } = generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});
privateKey = priv;
publicKey = pub;

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    realUsername = input;  // Store the real username
    registeredUsername = input;
    console.log(`Welcome, ${username} to the chat`);

    // Register user's public key with the server
    socket.emit("registerPublicKey", { username, publicKey });
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        if ((match = message.match(/^!impersonate (\w+)$/))) {
          username = match[1];
          impersonating = true; // Mark as impersonating
          console.log(`Now impersonating as ${username}`);
        } else if (message.match(/^!exit$/)) {
          username = registeredUsername; // Revert to real username
          impersonating = false; // Stop impersonating
          console.log(`Now you are ${username}`);
        } else {
          // Sign the message before sending it (sign with real username unless impersonating)
          const currentUsername = impersonating ? username : realUsername;
          const signature = crypto
            .sign("sha256", Buffer.from(message), privateKey)
            .toString("base64");

          // Send the message along with the signature
          socket.emit("message", { username: currentUsername, message, signature });
        }
      }
      rl.prompt();
    });
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, publicKey);
  console.log(`${username} joined the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, signature } = data;

  // Check if signature exists, if not, flag as a possible impersonation
  if (!signature) {
    console.log(`WARNING: Message from ${senderUsername} without signature. Possible impersonation!`);
    rl.prompt();
    return;
  }

  const senderPublicKey = users.get(senderUsername);

  // Check if public key exists for sender, if not flag as impersonation
  if (!senderPublicKey) {
    console.log(`WARNING: No public key found for ${senderUsername}. Possible impersonation!`);
    rl.prompt();
    return;
  }

  // Verify the signature using the sender's public key
  try {
    const isVerified = crypto.verify(
      "sha256",
      Buffer.from(senderMessage),
      { key: senderPublicKey, format: "pem", type: "spki" },
      Buffer.from(signature, "base64")
    );

    if (isVerified) {
      // If it's the current user's own message, don't display their name
      if (senderUsername === realUsername) {
        console.log(`${senderMessage}`);
      } else {
        console.log(`${senderUsername}: ${senderMessage}`);
      }
    } else {
      // If it's a message with an invalid signature, show the warning for other users
      console.log(`${senderUsername}: ${senderMessage} (WARNING: This user is fake!)`);
    }
  } catch (err) {
    console.error(`Error verifying message from ${senderUsername}: ${err.message}`);
  }

  rl.prompt();
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
